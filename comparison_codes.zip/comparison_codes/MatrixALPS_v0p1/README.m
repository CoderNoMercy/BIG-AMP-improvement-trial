%Only the ALPS codes are required for the BiG-AMP comparison. Please see 
%http://lions.epfl.ch/technology for other files in the Matrix ALPS
%package. They have been omitted to reduce the download size of BiG-AMP
