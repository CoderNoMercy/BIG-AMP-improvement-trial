function a = norm1(M)

a = sum(sum(abs(M)));