function vecA = vec(A)

vecA = A(:);