function tSqr = square(t)

tSqr = t * t;