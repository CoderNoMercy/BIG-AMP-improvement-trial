function i = argmax(v),

[dc,i] = max(v); 