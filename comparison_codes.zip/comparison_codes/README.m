%The codes provided in this folder were downloaded from the web sites of
%the various authors. They are provided, along with slightly modified
%versions for benchmarking purposes, to allow reproduction of examples in
%the BiG-AMP papers. These code are the property of their authors and
%should only be used as directed in their individual licenses. 